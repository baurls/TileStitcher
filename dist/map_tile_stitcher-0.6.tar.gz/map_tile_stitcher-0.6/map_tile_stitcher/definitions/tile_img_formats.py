IMG_FORMAT_JPG = ("jpg", "JPEG")
IMG_FORMAT_PNG = ("png", "PNG")
